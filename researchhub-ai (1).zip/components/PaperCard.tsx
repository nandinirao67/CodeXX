
import React from 'react';
import { Paper } from '../types';

interface PaperCardProps {
  paper: Paper;
  onImport?: (paper: Paper) => void;
  isImported?: boolean;
}

const PaperCard: React.FC<PaperCardProps> = ({ paper, onImport, isImported }) => {
  return (
    <div className="group relative flex flex-col h-full bg-white dark:bg-slate-900 rounded-[2rem] border-2 border-slate-100 dark:border-slate-800 shadow-sm hover:shadow-2xl hover:border-indigo-500/30 transition-all duration-500 p-6 overflow-hidden">
      {/* Decorative Gradient Accent */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-indigo-500/10 to-purple-500/10 rounded-bl-full opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      
      <div className="flex justify-between items-center mb-4">
        <span className="px-3 py-1 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 text-[10px] font-black uppercase tracking-widest rounded-lg">
          {paper.journal || 'Academic Journal'}
        </span>
        <span className="text-xs font-bold text-slate-400 dark:text-slate-500">{paper.year}</span>
      </div>
      
      <div className="mb-4">
        <h3 className="text-xl font-black text-slate-800 dark:text-white line-clamp-2 leading-tight group-hover:text-indigo-500 transition-colors duration-300">
          {paper.title}
        </h3>
        <p className="text-sm font-semibold text-slate-500 dark:text-slate-400 mt-2">
          {paper.authors.slice(0, 2).join(', ')}
          {paper.authors.length > 2 ? ' et al.' : ''}
        </p>
      </div>

      <p className="text-sm text-slate-600 dark:text-slate-400 line-clamp-3 italic leading-relaxed mb-6 opacity-80">
        {paper.abstract}
      </p>

      <div className="flex flex-wrap gap-2 mb-8">
        {paper.tags.slice(0, 3).map((tag, i) => (
          <span key={i} className="px-3 py-1 bg-slate-50 dark:bg-slate-800 text-slate-500 dark:text-slate-400 text-[10px] font-bold rounded-full border border-slate-100 dark:border-slate-700 uppercase tracking-tighter">
            #{tag}
          </span>
        ))}
      </div>

      <div className="mt-auto pt-6 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2 text-[10px] font-black text-slate-400 uppercase tracking-widest">
          <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z" />
          </svg>
          {paper.citations.toLocaleString()} Citations
        </div>
        
        {onImport && (
          <button
            onClick={() => !isImported && onImport(paper)}
            disabled={isImported}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all duration-300 transform ${
              isImported 
              ? 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 cursor-default' 
              : 'bg-indigo-600 text-white hover:bg-indigo-700 active:scale-95 shadow-lg shadow-indigo-600/20'
            }`}
          >
            {isImported ? (
              <>
                <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                </svg>
                Archived
              </>
            ) : (
              <>
                <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 4v16m8-8H4" />
                </svg>
                Import
              </>
            )}
          </button>
        )}
      </div>
    </div>
  );
};

export default PaperCard;
